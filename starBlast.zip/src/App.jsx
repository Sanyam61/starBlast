import React from "react";
import "./App.css";

function App(props) {
  return (
    <div className="star_wrapper_box">
      <div className="component_box"></div>
        <div class="sky">
          <div class="star"></div>
        </div>
      <div className="component_box"></div>
    </div>
  );
}

export default App;
